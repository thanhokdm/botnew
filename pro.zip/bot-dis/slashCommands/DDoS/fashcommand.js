const {
    MessageEmbed,
    MessageActionRow,
    MessageButton
} = require('discord.js');
const ayarlar = require('../../ayarlar.json');
const https = require('https');
const fs = require('fs');
const moment = require('moment');
var version = ayarlar['versionbot'];
var roleID5 = ayarlar['roleID5'];
var img = ayarlar['img'];
module['exports'] = {
    name: 'stopspam',
    description: 'Sử dụng lệnh stop nhanh',
    type: 'CHAT_INPUT',
    run: async(_0x36a5x7, _0x36a5x8) => {
         if (!_0x36a5x8['member']['roles']['cache']['has'](roleID5)) {
            return _0x36a5x8['reply']({
                       embeds: [new MessageEmbed()['setColor']('RANDOM')['setDescription'](`${'Ch\u1EC9 c\xF3 <@&'}${roleID5}${'> m\u1EDBi \u0111\u01B0\u1EE3c d\xF9ng l\u1EC7nh n\xE0y.'}`)['setFooter']({
                    text: '\xA9 Developer: NguyenThanh'
                })['setTimestamp']()]
            })
        };
        const _0x36a5x9 = new MessageActionRow()['addComponents'](new MessageButton()['setCustomId']('SMS')['setLabel']('Stop All Spam')['setStyle']('SUCCESS')['setEmoji']('💻'));
        const _0x36a5xa = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('```css\x0A[ SỬ DỤNG LỆNH NHANH ]\x0A```')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
        await _0x36a5x8['reply']({
            embeds: [_0x36a5xa],
            components: [_0x36a5x9]
        });
        _0x36a5x7['on']('interactionCreate', async(_0x36a5x8) => {
            if (!_0x36a5x8['isButton']()) {
                return
            };
            if (_0x36a5x8['customId'] === 'SMS') {
                var _0x36a5x10 = require('child_process')['exec'];
                _0x36a5x10(`${'taskkill /f /im python.exe'}`, (_0x36a5x11, _0x36a5x12, _0x36a5x13) => {});
                console['log']('D\u1EEBng l\u1EA1i t\u1EA5t c\u1EA3 cu\u1ED9c t\u1EA5n c\xF4ng:' + _0x36a5x8['guild']['id']);
                const _0x36a5xa = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('```css\x0A[ T\u1EA4T C\u1EA2 CU\u1ED8C SPAM \u0110\xC3 D\u1EEANG L\u1EA0I ]\x0A```')['setFooter']('\xA9 Developer: NguyenThanh', img)['setTimestamp']();
                const _0x36a5xf = require('util')['promisify'](setTimeout);
                await _0x36a5xf(1000);
                await _0x36a5x8['reply']({
                    embeds: [_0x36a5xa],
                    ephemeral: true
                })
            }
        })
    }
}