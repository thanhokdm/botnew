const { MessageEmbed } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");
const os = require("os");

module.exports = {
  name: "status",
  description: "Xem trạng thái bot",
  type: 'CHAT_INPUT',

  run: async (client, interaction) => {
    await interaction.deferReply({
      ephemeral: false,
    });

    const uptime = moment
      .duration(interaction.client.uptime)
      .format(" D [days], H [hrs], m [mins], s [secs]");
    let channelCount = client.channels.cache.size;
    let serverCount = client.guilds.cache.size;
    let memberCount = 0;
    client.guilds.cache.forEach((guild) => {
      memberCount += guild.memberCount;
    });

    const statusEmbed = new MessageEmbed()
      .setTitle(`\`🔎 Số liệu thống kê của ${client.user.username}\``)
      .setColor(client.embedColor)
      .setFields([
        {
          name: "`Máy chủ`",
          value: `\`\`\`ini\n[ ${serverCount} ]\n\`\`\``,
          inline: true,
        },
        {
          name: "`Kênh`",
          value: `\`\`\`ini\n[ ${channelCount} ]\n\`\`\``,
          inline: true,
        },
        {
          name: "`Người dùng`",
          value: `\`\`\`ini\n[ ${memberCount} ]\n\`\`\``,
          inline: true,
        },
        {
          name: "`Thời gian hoạt động`",
          value: `\`\`\`ini\n[ ${uptime} ]\n\`\`\``,
          inline: true,
        },

        {
          name: "`Tổng bộ nhớ`",
          value: `\`\`\`ini\n[ ${(os.totalmem() / 1024 / 1024).toFixed(
            2
          )} MB ]\n\`\`\``,
          inline: true,
        },
        {
          name: "`Bộ nhớ trống`",
          value: `\`\`\`ini\n[ ${(os.freemem() / 1024 / 1024).toFixed(
            2
          )} MB ]\n\`\`\``,
          inline: true,
        },
        {
          name: "`Tổng số đống`",
          value: `\`\`\`ini\n[ ${(
            process.memoryUsage().heapTotal /
            1024 /
            1024
          ).toFixed(2)} MB ]\n\`\`\``,
          inline: true,
        },
        {
          name: "`Sử dụng đống`",
          value: `\`\`\`ini\n[ ${(
            process.memoryUsage().heapUsed /
            1024 /
            1024
          ).toFixed(2)} MB ]\n\`\`\``,
          inline: true,
        },
      ])
      .setFooter({ text: "© kiemhuy#0250" })
      .setTimestamp();
    await interaction.editReply({ embeds: [statusEmbed] });
  },
};
/**
 * Coded By: Abel Purnwasy
 */
